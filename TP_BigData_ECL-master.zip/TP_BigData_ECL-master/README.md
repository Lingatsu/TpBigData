# Fichiers pour les TPs Big-Data

Ce repo contient les fichiers nécessaires à la réalisation de différents TPs concernant le Big-Data (SparQL, Hadoop, Spark), enseignés à l'École Centrale de Lyon.


[_stéphane Derrode_](mailto:stephane.derrode@ec-lyon.fr), dpt MI/ECL, équipe Imagine/LIRIS.
