#!/bin/bash

curl -s --remote-name https://fsapps.nwcg.gov/afm/data/fireptdata/modis_fire_2018_365_conus_shapefile.zip
unzip modis_fire_2018_365_conus_shapefile.zip
curl -s --remote-name https://fsapps.nwcg.gov/afm/data/fireptdata/modis_fire_2017_365_conus_shapefile.zip
unzip modis_fire_2017_365_conus_shapefile.zip
curl -s --remote-name https://fsapps.nwcg.gov/afm/data/fireptdata/modis_fire_2016_366_conus_shapefile.zip
unzip modis_fire_2016_366_conus_shapefile.zip
curl -s --remote-name https://fsapps.nwcg.gov/afm/data/fireptdata/modis_fire_2015_365_conus_shapefile.zip
unzip modis_fire_2015_365_conus_shapefile.zip
rm *.prj *.shp *.shx *.zip